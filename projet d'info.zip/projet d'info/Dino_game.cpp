#include "raylib.h"
#include <string>
#include <cmath>
#include <vector>

// ============ STRUCTURES ============
struct AnimData
{
    Rectangle rec;     // Rectangle de la texture pour l'animation
    Vector2 pos;       // Position à l'écran
    int frame;         // Frame actuelle de l'animation
    float updateTime;  // Intervalle de mise à jour de l'animation
    float runntingTime;// Temps accumulé pour l'animation
    bool isFlying;     // Détermine si l'objet vole
    float baseY;       // Position de base verticale pour le vol
    float flyTime;     // Temps écoulé pour le mouvement de vol
};

struct GameState
{
    // Player
    AnimData dinoData;
    float dinoVelocity;
    bool isDucking;
    int lives;
    int score;
    int argent;
    int bestScore; 

    // Enemies
    std::vector<AnimData> laevas;
    std::vector<AnimData> melons;

    // Background
    AnimData mountainData;

    // Game state
    bool inMenu;
    bool gameOver;
    bool musicOn;
    float objectSpeed;
    float gameTime;

    // Resources
    Texture2D dinoTex;
    Texture2D laevaTex;
    Texture2D melonTex;
    Texture2D mountainTex;
    Texture2D heartTex;

    // Audio
    Sound jumpSound;
    Sound melonSound;
    Sound hurtSound;
    Sound gameOverSound; // Ajout du son de game over
    Music bgMusic;
};

// ============ FONCTIONS UTILITAIRES ============
bool IsOnGround(const AnimData &data, int windowHeight)
{
    return data.pos.y >= (windowHeight - 80) - data.rec.height;
}

AnimData UpdateAnimData(AnimData data, float deltaTime, int maxFrame)
{
    data.runntingTime += deltaTime;
    if (data.runntingTime >= data.updateTime)
    {
        data.runntingTime = 0.0f;
        data.rec.x = data.frame * data.rec.width;
        data.frame++;
        if (data.frame > maxFrame)
        {
            data.frame = 0;
        }
    }
    return data;
}

// ============ FONCTIONS D'INITIALISATION ============
void LoadResources(GameState &state)
{
    // Charger les textures
    state.dinoTex = LoadTexture("textures/d.png");
    state.laevaTex = LoadTexture("textures/LAEVA.png");
    state.melonTex = LoadTexture("textures/Yellow Watermelon2.png");
    state.mountainTex = LoadTexture("textures/mountain.png");
    state.heartTex = LoadTexture("textures/heart.png");

    // Charger les sons
    state.jumpSound = LoadSound("Sounds/jump.wav");
    state.melonSound = LoadSound("Sounds/pickupCoin.ogg");
    state.hurtSound = LoadSound("Sounds/hitHurt.wav");
    state.gameOverSound = LoadSound("Sounds/gameOver.mp3"); // Charger le son de game over
    state.bgMusic = LoadMusicStream("Sounds/PixelKings.mp3");
}

void UnloadResources(GameState &state)
{
    // Décharger les textures
    UnloadTexture(state.dinoTex);
    UnloadTexture(state.laevaTex);
    UnloadTexture(state.melonTex);
    UnloadTexture(state.mountainTex);
    UnloadTexture(state.heartTex);

    // Décharger les sons
    UnloadSound(state.jumpSound);
    UnloadSound(state.melonSound);
    UnloadSound(state.hurtSound);
    UnloadSound(state.gameOverSound); // Décharger le son de game over
    UnloadMusicStream(state.bgMusic);
}

void InitGameState(GameState &state, int windowWidth, int windowHeight)
{
    // Initialiser les valeurs
    state.dinoVelocity = 0.0f;
    state.isDucking = false;
    state.lives = 3;
    state.score = 0;
    state.argent = 0;
    state.inMenu = true;
    state.gameOver = false;
    state.musicOn = true;
    state.objectSpeed = 500.0f;
    state.gameTime = 0.0f;

    // Initialiser le dino
    state.dinoData.rec.width = state.dinoTex.width / 4.0f;
    state.dinoData.rec.height = (float)state.dinoTex.height;
    state.dinoData.rec.x = 0;
    state.dinoData.rec.y = 0;
    state.dinoData.pos.x = windowWidth / 3.0f - state.dinoData.rec.width / 2.0f;
    state.dinoData.pos.y = (windowHeight - 80) - state.dinoData.rec.height;
    state.dinoData.frame = 0;
    state.dinoData.runntingTime = 0;
    state.dinoData.updateTime = 0.1f;

     // Initialiser les Laevas
    const int numLaevas = 6;
    state.laevas.resize(numLaevas);
    int laevaDist = 100;
    for (int i = 0; i < numLaevas; i++)
    {
        state.laevas[i].rec = {0, 0, state.laevaTex.width / 4.0f, (float)state.laevaTex.height};
        state.laevas[i].pos = {(float)(windowWidth + laevaDist), (float)(windowHeight - 100 - state.laevaTex.height)};
        state.laevas[i].frame = 0;
        state.laevas[i].runntingTime = 0.0f;
        state.laevas[i].updateTime = 0.2f;
        laevaDist += 10000;
    
    state.laevas[i].isFlying = (i % 4 == 0); // 1 sur 4 vole
    state.laevas[i].flyTime = 0.0f;

    if (state.laevas[i].isFlying)
    {
        state.laevas[i].baseY = windowHeight - 260;
        state.laevas[i].pos.y = state.laevas[i].baseY;
    }
    }

    // Initialiser les melons
    const int numMelons = 3;
    state.melons.resize(numMelons);
    int melonDist = 1000;
    for (int i = 0; i < numMelons; i++)
    {
        state.melons[i].rec = {0, 0, (float)state.melonTex.width, (float)state.melonTex.height};
        state.melons[i].pos = {(float)(windowWidth + melonDist + i * 800), (float)(windowHeight - 200 - state.melonTex.height)};
        state.melons[i].frame = 0;
        state.melons[i].runntingTime = 0.0f;
        state.melons[i].updateTime = 0.2f;
        melonDist += 2000;
    }

    // Initialiser le background
    state.mountainData.rec = {0, 0, (float)state.mountainTex.width, (float)state.mountainTex.height};
    state.mountainData.pos = {0.0f, 0.0f};
}

// ============ FONCTIONS DE MISE À JOUR ============
void UpdatePlayer(GameState &state, float deltaTime, int windowHeight)
{
    const int JUMP_HEIGHT = 800;
    const int GRAVITY = 2000;

    // Gravité et saut
    if (IsOnGround(state.dinoData, windowHeight))
    {
        state.dinoVelocity = 0.0f;
    }
    else
    {
        state.dinoVelocity += GRAVITY * deltaTime;
    }

    // Saut
    if ((IsKeyPressed(KEY_SPACE) && IsOnGround(state.dinoData, windowHeight)) ||
        (IsKeyPressed(KEY_W) && IsOnGround(state.dinoData, windowHeight)))
    {
        state.dinoVelocity -= JUMP_HEIGHT;
        PlaySound(state.jumpSound);
    }

    // Accroupissement
    if (IsKeyPressed(KEY_S))
    {
        state.isDucking = true;
    }

    static float duckTime = 0.0f;
    if (state.isDucking && duckTime < 0.45f)
    {
        duckTime += deltaTime;
        state.dinoData.rec.x = 3 * state.dinoData.rec.width; // Frame d'accroupissement
    }
    else
    {
        duckTime = 0.0f;
        state.isDucking = false;
        state.dinoData = UpdateAnimData(state.dinoData, deltaTime, 2);
    }

    // Mettre à jour la position
    state.dinoData.pos.y += state.dinoVelocity * deltaTime;
}

void UpdateEnemies(GameState &state, float deltaTime, int windowWidth)
{
    // Mettre a jour les Laevas
    for (auto &laeva : state.laevas)
    {
        //Animation
        laeva = UpdateAnimData(laeva, deltaTime, 3);

        //Deplacement horizontal
        laeva.pos.x -= state.objectSpeed * deltaTime;

        //RESET QUAND HORS ÉCRAN  
        if (laeva.pos.x <= -laeva.rec.width)
        {
            laeva.pos.x = windowWidth + GetRandomValue(500, 1200);
            laeva.flyTime = 0.0f;
        }

        //Comportement volant
        if (laeva.isFlying)
        {
            laeva.flyTime += deltaTime;
            laeva.pos.y = laeva.baseY + sinf(laeva.flyTime * 3.0f) * 80.0f;
        }
    }


    // Mettre a jour les melons
    for (auto &melon : state.melons)
    {
        if (melon.pos.x <= -melon.rec.width)
        {
            melon.pos.x = windowWidth + GetRandomValue(2000, 20000);
        }
        else
        {
            melon.pos.x -= state.objectSpeed * deltaTime;
        }
    }
}

bool CheckLaevaCollisions(GameState &state)
{
    for (auto &laeva : state.laevas)      // Parcour de tous les ennemis laevas
    {
        float laevaPad = 30.0f;
        Rectangle laevaRec{
            laeva.pos.x + laevaPad,
            laeva.pos.y + laevaPad,
            laeva.rec.width - 2.0f * laevaPad,
            laeva.rec.height - 2.0f * laevaPad};

        float dinoPad = 30.0f;
        Rectangle dinoRec{
            state.dinoData.pos.x + dinoPad,
            state.dinoData.pos.y + dinoPad,
            state.dinoData.rec.width - 2.0f * dinoPad,
            state.dinoData.rec.height - 2.0f * dinoPad};

        if (CheckCollisionRecs(laevaRec, dinoRec) && !state.isDucking)     // Verifie si le dino touche l'ennemi et qu'il n'est pas accroupi
        {
            if (state.lives > 0)
            {
                state.lives--;
                laeva.pos.x = 1280 + GetRandomValue(3000, 10000);
                PlaySound(state.hurtSound);
            }

            if (state.lives <= 0)
            {
                return true;
            }
        }
    }

    return false;
}

void CheckMelonCollisions(GameState &state)
{
    for (auto &melon : state.melons)
    {
        float melonPad = 5.0f;
        Rectangle melonRec{
            melon.pos.x + melonPad,
            melon.pos.y + melonPad,
            melon.rec.width - 2.0f * melonPad,
            melon.rec.height - 2.0f * melonPad};

        float dinoPad = 30.0f;
        Rectangle dinoRec{
            state.dinoData.pos.x + dinoPad,
            state.dinoData.pos.y + dinoPad,
            state.dinoData.rec.width - 2.0f * dinoPad,
            state.dinoData.rec.height - 2.0f * dinoPad};

        if (CheckCollisionRecs(melonRec, dinoRec))
        {
            PlaySound(state.melonSound);
            state.score += 10;
            state.argent += 10;
            melon.pos.x = 1280 + GetRandomValue(2000, 20000);
        }
    }
}

// ============ FONCTIONS DE DESSIN ============
void DrawGradientBackground(int windowWidth, int windowHeight, Color color1, Color color2)
{
    for (int i = 0; i < windowHeight; i++)
    {
        float t = (float)i / windowHeight;
        Color lineColor = {
            (unsigned char)((1 - t) * color1.r + t * color2.r),
            (unsigned char)((1 - t) * color1.g + t * color2.g),
            (unsigned char)((1 - t) * color1.b + t * color2.b),
            255};
        DrawLine(0, i, windowWidth, i, lineColor);

        for (int p = 0; p < 2; p++)
        {
            int px = GetRandomValue(0, windowWidth);
            int py = GetRandomValue(i, i + 1);
            DrawPixel(px, py, WHITE);
        }
    }
}

void DrawMenu(const GameState &state, float time, int windowWidth, int windowHeight)
{
    Color bgColor1 = {40, 0, 70, 255};
    Color bgColor2 = {10, 10, 40, 255};

    DrawGradientBackground(windowWidth, windowHeight, bgColor1, bgColor2);

    // Titre
    const char *titleText = "STORY OF LYREN";
    int titleWidth = MeasureText(titleText, 60);
    int titleY = 100 + (int)(10 * sin(time * 2));

    for (int i = 4; i >= 1; i--)
        DrawText(titleText, windowWidth / 2 - titleWidth / 2 + i, titleY + i, 60, {0, 0, 0, 100});

    DrawText(titleText, windowWidth / 2 - titleWidth / 2, titleY, 60, GOLD);

    // Texte d'information
    const char *infoText = "Beyond the Asteroid: Discover Lyren's True Journey";
    int infoWidth = MeasureText(infoText, 30);
    int infoY = 220 + (int)(5 * sin(time * 3));
    DrawText(infoText, windowWidth / 2 - infoWidth / 2, infoY, 30, WHITE);

    // Bouton START
    Rectangle startButton = {(float)windowWidth / 2.0f - 150.0f, 400.0f, 300.0f, 60.0f};
    Vector2 mousePoint = GetMousePosition();
    bool hoverStart = CheckCollisionPointRec(mousePoint, startButton);
    float pulse = 5.0f * sin(time * 5.0f);

    DrawRectangleRounded((Rectangle){startButton.x - pulse / 2.0f, startButton.y - pulse / 2.0f,
                                     startButton.width + pulse, startButton.height + pulse},
                         0.25f, 4, hoverStart ? SKYBLUE : DARKBLUE);

    DrawText("START", (int)(startButton.x + startButton.width / 2.0f - MeasureText("START", 40) / 2),
             (int)(startButton.y + 15), 40, WHITE);

    // Texte clignotant
    if (fmod(time, 1.0) < 0.5)
    {
        const char *enterText = ">>> PRESS ENTER OR CLICK START <<<";
        int enterWidth = MeasureText(enterText, 30);
        DrawText(enterText, windowWidth / 2 - enterWidth / 2, 600 + (int)(5 * sin(time * 3)), 20, WHITE);
    }

    // Contrôles
    DrawText("CONTROLS", 850, 450, 40, RED);
    DrawText(">>SPACE<< TO JUMP OVER AXES", 800, 500, 20, BLUE);
    DrawText(">>S<< TO DUCK UNDER AXES", 800, 550, 20, BLUE);
    DrawText(">>Q<< TO TURN MUSIC OFF", 800, 600, 20, BLUE);
    DrawText(">>E<< TO TURN MUSIC ON", 800, 650, 20, BLUE);
}

void DrawGame(const GameState &state, int windowWidth, int windowHeight)
{
    // Lignes de décor
    DrawLine(0, (windowHeight - 350) + (int)state.dinoData.rec.height, windowWidth,
             (windowHeight - 350) + (int)state.dinoData.rec.height, BLACK);

    // Montagnes
    DrawTexture(state.mountainTex, 0, 0, WHITE);

    // Autre ligne
    DrawLine(0, (windowHeight - 250) + (int)state.dinoData.rec.height, windowWidth,
             (windowHeight - 250) + (int)state.dinoData.rec.height, BLACK);

    // Dino
    DrawTextureRec(state.dinoTex, state.dinoData.rec, state.dinoData.pos, WHITE);

    // Laevas
    for (const auto &laeva : state.laevas)
    {
        DrawTextureRec(state.laevaTex, laeva.rec, laeva.pos, WHITE);
    }

    // Melons
    for (const auto &melon : state.melons)
    {
        DrawTextureRec(state.melonTex, melon.rec, melon.pos, WHITE);
    }
}

void DrawUI(const GameState &state, int windowWidth)
{
    // Argent
    std::string argentStr = "Argent: " + std::to_string(state.argent);
    DrawText(argentStr.c_str(), 50, 100, 30, BLACK);

    // Score
    std::string scoreStr = "Score: " + std::to_string(state.score);
    DrawText(scoreStr.c_str(), 450, 100, 30, BLACK);

    // Vies
    std::string livesStr = "Lives: " + std::to_string(state.lives);
    int liveX = 850;
    int liveY = 100;
    DrawText(livesStr.c_str(), liveX, liveY, 30, RED);

    // Coeurs
    int textWidth = MeasureText(livesStr.c_str(), 30);
    for (int i = 0; i < state.lives; i++)
    {
        DrawTexture(state.heartTex, liveX + textWidth + 10 + i * (state.heartTex.width + 5), liveY, WHITE);
    }

    // Meilleur score
    std::string bestScoreText = "Best Score: " + std::to_string(state.bestScore);
    DrawText(bestScoreText.c_str(), 1100, 100, 20, GREEN);

    }

void DrawGameOver(const GameState &state, float time, int windowWidth, int windowHeight)
{
    Color bgColor1 = {40, 0, 70, 255};
    Color bgColor2 = {10, 10, 40, 255};

    DrawGradientBackground(windowWidth, windowHeight, bgColor1, bgColor2);

    // Texte Game Over
    float scale = 1.0f + 0.1f * sin(time * 3.0f);
    const char *line1 = "LYREN DIED";
    DrawText(line1, windowWidth / 2 - MeasureText(line1, 60) / 2, 150, 60, RED);

    const char *line2 = "GAME OVER !!!";
    DrawText(line2, windowWidth / 2 - MeasureText(line2, 100) / 2, 300, (int)(100 * scale), RED);

    // Score, Argent, et Meilleur score
    std::string finalScoreText = "Score: " + std::to_string(state.score) +
                             " | Argent: " + std::to_string(state.argent) +
                             " | Best Score: " + std::to_string(state.bestScore);
    // Centrer le texte sur la fenetre
    DrawText(finalScoreText.c_str(), windowWidth / 2 - MeasureText(finalScoreText.c_str(), 40) / 2, 450, 40, WHITE);

    // Bouton RESTART
    Rectangle restartButton = {(float)windowWidth / 2.0f - 150.0f, 520.0f, 300.0f, 60.0f};
    Vector2 mousePoint = GetMousePosition();
    bool hoverRestart = CheckCollisionPointRec(mousePoint, restartButton);
    float pulse = 5.0f * sin(time * 5.0f);

    DrawRectangleRounded((Rectangle){restartButton.x - pulse / 2.0f, restartButton.y - pulse / 2.0f,
                                     restartButton.width + pulse, restartButton.height + pulse},
                         0.25f, 4, hoverRestart ? SKYBLUE : DARKBLUE);

    DrawText("RESTART", (int)(restartButton.x + restartButton.width / 2.0f - MeasureText("RESTART", 40) / 2), (int)(restartButton.y + 15), 40, WHITE);

    // Instructions
    const char *instructionsText = ">>> Press ENTER to restart or ESC to exit <<<";
    float scale2 = 1.0f + 0.1f * sin(time * 5.0f);
    int scaledFontSize = (int)(20 * scale2);
    int instrWidth = MeasureText(instructionsText, scaledFontSize);
    DrawText(instructionsText, windowWidth / 2 - instrWidth / 2, 650, scaledFontSize, WHITE);

}

// ============ FONCTION MAIN ============
int main()
{
    // Initialisation de la fenêtre
    const int windowWidth = 1280;
    const int windowHeight = 720;
    InitWindow(windowWidth, windowHeight, "Made by Isra & Loukman");

    // Initialisation audio
    InitAudioDevice();

    // État du jeu
    GameState gameState;

    // Variable pour le son de game over
    static bool gameOverSoundPlayed = false;

    // Charger les ressources
    LoadResources(gameState);

    // Initialiser l'etat du jeu
    InitGameState(gameState, windowWidth, windowHeight);
    gameState.bestScore = 0;

    // Variables pour la musique
    bool musicStarted = false;

    SetTargetFPS(60);

    // Boucle principale
    while (!WindowShouldClose())
    {
        float deltaTime = GetFrameTime();
        float time = GetTime();

        // Gestion de la musique du menu
        if (gameState.inMenu && !musicStarted)
        {
            PlayMusicStream(gameState.bgMusic);
            musicStarted = true;
        }

        if (musicStarted)
        {
            UpdateMusicStream(gameState.bgMusic);
        }

        // Gestion des etats
        if (gameState.inMenu)
        {
            // Verifier le clic sur le bouton START
            Rectangle startButton = {(float)windowWidth / 2.0f - 150.0f, 400.0f, 300.0f, 60.0f};
            Vector2 mousePoint = GetMousePosition();
            bool hoverStart = CheckCollisionPointRec(mousePoint, startButton);

            if ((hoverStart && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) || IsKeyPressed(KEY_ENTER))
            {
                gameState.inMenu = false;
                StopMusicStream(gameState.bgMusic);
                musicStarted = false;
            }
        }
        else if (gameState.gameOver)
        {
            // Gestion du game over
            Rectangle restartButton = {(float)windowWidth / 2.0f - 150.0f, 520.0f, 300.0f, 60.0f};
            Vector2 mousePoint = GetMousePosition();
            bool hoverRestart = CheckCollisionPointRec(mousePoint, restartButton);

            if ((hoverRestart && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) || IsKeyPressed(KEY_ENTER))
            {
                // Reinitialiser le jeu
                InitGameState(gameState, windowWidth, windowHeight);
                musicStarted = false;
                gameOverSoundPlayed = false; // reinitialisation du son de game over
            }

            if (IsKeyPressed(KEY_ESCAPE))
            {
                break;
            }
        }
        else
        {
            // Mise a jour du jeu en cours
            gameState.gameTime += deltaTime;

            // Augmentation progressive de la difficulté
            static float pointRunningTime = 0.0f;
            pointRunningTime += deltaTime;
            if (pointRunningTime >= 1.0f)
            {
                pointRunningTime = 0.0f;
                gameState.score++;
                if (gameState.objectSpeed < 700.0f)
                {
                    gameState.objectSpeed += 10.0f;
                }
            }

            // Gestion de la musique
            if (gameState.musicOn && !IsMusicStreamPlaying(gameState.bgMusic))
            {
                PlayMusicStream(gameState.bgMusic);
            }
            else if (!gameState.musicOn && IsMusicStreamPlaying(gameState.bgMusic))
            {
                StopMusicStream(gameState.bgMusic);
            }

            if (IsMusicStreamPlaying(gameState.bgMusic))
            {
                UpdateMusicStream(gameState.bgMusic);
            }

            // Controles musique
            if (IsKeyPressed(KEY_Q) && gameState.musicOn)
                gameState.musicOn = false;
            if (IsKeyPressed(KEY_E) && !gameState.musicOn)
                gameState.musicOn = true;

            // Mises a jour du joueur et ennemis
            UpdatePlayer(gameState, deltaTime, windowHeight);
            UpdateEnemies(gameState, deltaTime, windowWidth);

            // Gestion collisions Laeva avec son de game over
            if (CheckLaevaCollisions(gameState))
            {
                if (!gameState.gameOver)
                {
                    gameState.gameOver = true;

                    if (!gameOverSoundPlayed)
                    {
                        PlaySound(gameState.gameOverSound);
                        gameOverSoundPlayed = true;
                    }

                    // Mettre a jour le meilleur score
                    if (gameState.score > gameState.bestScore)
                        gameState.bestScore = gameState.score;
                }
            }

            // Collisions melons
            CheckMelonCollisions(gameState);
        }

        // Dessin
        BeginDrawing();
        ClearBackground(BLACK);

        if (gameState.inMenu)
        {
            DrawMenu(gameState, time, windowWidth, windowHeight);
        }
        else if (gameState.gameOver)
        {
            DrawGameOver(gameState, time, windowWidth, windowHeight);
        }
        else
        {
            DrawGame(gameState, windowWidth, windowHeight);
            DrawUI(gameState, windowWidth);
        }

        EndDrawing();
    }

    // Nettoyage
    UnloadResources(gameState);
    CloseAudioDevice();
    CloseWindow();

    return 0;
}
