#include "raylib.h"

// ================= STRUCT =================
struct AnimData
{
    Rectangle rec;
    Vector2 pos;
    int frame;
    float runningTime;
    float updateTime;
};

// ================= GLOBAL =================
Texture2D idleTex;
Texture2D runTex;
Texture2D jumpTex;
Texture2D attackTex;

Texture2D* currentTex;
AnimData hero;

bool attacking = false;
float attackTimer = 0.0f;

float velocityY = 0.0f;
const float gravity = 2000.0f;
const float jumpForce = 800.0f;

// ================= FUNCTIONS =================
AnimData UpdateAnim(AnimData data, float dt, int maxFrame)
{
    data.runningTime += dt;
    if (data.runningTime >= data.updateTime)
    {
        data.runningTime = 0;
        data.frame++;
        if (data.frame > maxFrame) data.frame = 0;
        data.rec.x = data.frame * data.rec.width;
    }
    return data;
}

void SetAnimation(Texture2D& tex, int frames)
{
    if (currentTex != &tex)
    {
        currentTex = &tex;
        hero.frame = 0;
        hero.runningTime = 0;
        hero.rec.width = tex.width / frames;
        hero.rec.height = tex.height;
        hero.rec.x = 0;
        hero.rec.y = 0;
    }
}

bool IsOnGround()
{
    return hero.pos.y >= 500;
}

// ================= MAIN =================
int main()
{
    InitWindow(1280, 720, "Hero Sword Test");
    SetTargetFPS(60);

    // LOAD TEXTURES
    idleTex   = LoadTexture("textures/hero/no_weapon/idle.png");
    runTex    = LoadTexture("textures/hero/no_weapon/run.png");
    jumpTex   = LoadTexture("textures/hero/no_weapon/jump.png");
    attackTex = LoadTexture("textures/hero/with_sword/attack.png");

    currentTex = &idleTex;

    hero.rec.width = idleTex.width / 8;   // ⚠️ ajuste si pas 8 frames
    hero.rec.height = idleTex.height;
    hero.rec.x = 0;
    hero.rec.y = 0;

    hero.pos = {200, 500};
    hero.frame = 0;
    hero.runningTime = 0;
    hero.updateTime = 0.1f;

    // GAME LOOP
    while (!WindowShouldClose())
    {
        float dt = GetFrameTime();

        // GRAVITY
        if (!IsOnGround())
            velocityY += gravity * dt;
        else
            velocityY = 0;

        hero.pos.y += velocityY * dt;
        if (hero.pos.y > 500) hero.pos.y = 500;

        // ATTACK
        if (IsKeyPressed(KEY_J) && !attacking)
        {
            attacking = true;
            attackTimer = 0;
            SetAnimation(attackTex, 8);
        }

        if (attacking)
        {
            attackTimer += dt;
            hero = UpdateAnim(hero, dt, 7);

            if (attackTimer > 0.6f)
                attacking = false;
        }
        else
        {
            // JUMP
            if (IsKeyPressed(KEY_SPACE) && IsOnGround())
            {
                velocityY = -jumpForce;
                SetAnimation(jumpTex, 6);
            }
            // RUN
            else if (IsKeyDown(KEY_RIGHT))
            {
                hero.pos.x += 300 * dt;
                SetAnimation(runTex, 8);
                hero = UpdateAnim(hero, dt, 7);
            }
            // IDLE
            else
            {
                SetAnimation(idleTex, 8);
                hero = UpdateAnim(hero, dt, 7);
            }
        }

        // DRAW
        BeginDrawing();
        ClearBackground(RAYWHITE);

        DrawLine(0, 550, 1280, 550, BLACK); // ground

        DrawTextureRec(*currentTex, hero.rec, hero.pos, WHITE);

        DrawText("RIGHT = run | SPACE = jump | J = sword attack", 20, 20, 20, DARKGRAY);

        EndDrawing();
    }

    // CLEAN
    UnloadTexture(idleTex);
    UnloadTexture(runTex);
    UnloadTexture(jumpTex);
    UnloadTexture(attackTex);
    CloseWindow();

    return 0;
}
